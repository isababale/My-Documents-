# Chapter 4 Solutions

The end-of-chapter exercises focused on performing aggregations with `pandas`. The solutions can all be found in [`solutions.ipynb`](./solutions.ipynb).
