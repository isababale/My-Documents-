# Chapter 7 Solutions

The end-of-chapter exercises focused on using the [`stock_analysis`](https://github.com/stefmolin/stock-analysis) package to practice conducting financial analysis. The solutions can all be found in [`solutions.ipynb`](./solutions.ipynb).
