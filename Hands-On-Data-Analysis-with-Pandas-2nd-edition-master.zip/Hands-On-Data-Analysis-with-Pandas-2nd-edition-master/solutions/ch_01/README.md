# Chapter 1 Solutions

The end-of-chapter exercises focused on understanding statistics and working in JupyterLab. The solutions can all be found in [`solutions.ipynb`](./solutions.ipynb).
