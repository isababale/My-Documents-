# Chapter 8 Solutions

The end-of-chapter exercises focused on rule-based anomaly detection techniques. The solutions can all be found in [`solutions.ipynb`](./solutions.ipynb). Note that [`dec_2018_attacks.csv`](./dec_2018_attacks.csv) and [`dec_2018_log.csv`](./dec_2018_log.csv) contain the final output of the first exercise and are used for the remaining exercises.
