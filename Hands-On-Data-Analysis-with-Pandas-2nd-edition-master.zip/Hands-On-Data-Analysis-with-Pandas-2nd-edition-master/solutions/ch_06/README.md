# Chapter 6 Solutions

The end-of-chapter exercises focused on plotting with `seaborn` and customizing visualizations with reference lines, shaded regions, and annotations. The solutions can all be found in [`solutions.ipynb`](./solutions.ipynb).
