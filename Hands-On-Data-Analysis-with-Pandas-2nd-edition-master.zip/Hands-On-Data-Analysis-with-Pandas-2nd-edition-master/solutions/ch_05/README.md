# Chapter 5 Solutions

The end-of-chapter exercises focused on plotting with `pandas`. The solutions can all be found in [`solutions.ipynb`](./solutions.ipynb).
