# Chapter 2 Solutions

The end-of-chapter exercises focused on getting used to working with `DataFrame` objects. The solutions can all be found in [`solutions.ipynb`](./solutions.ipynb).
