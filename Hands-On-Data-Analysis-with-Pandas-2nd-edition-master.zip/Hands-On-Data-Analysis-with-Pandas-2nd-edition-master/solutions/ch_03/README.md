# Chapter 3 Solutions

The end-of-chapter exercises focused on data wrangling in `pandas`. The solutions can all be found in [`solutions.ipynb`](./solutions.ipynb). Note that [`faang.csv`](./faang.csv) contains the final output of the first exercise.
