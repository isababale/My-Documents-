# Appendix
Here are some workflow diagrams for reference.

## Data Analysis Workflow
<img src="./data_analysis_workflow.png" align="center" width="600" alt="data analysis workflow">

## Choosing the Appropriate Plot
<img src="./choosing_the_appropriate_plot_flow_chart.png" align="center" width="600" alt="choosing the appropriate plot">

## Machine Learning Workflow
<img src="./ml_workflow.png" align="center" width="600" alt="machine learning workflow">


<hr>
<div style="overflow: hidden; margin-bottom: 10px;">
    <div style="float: left;">
        <a href="../ch_12/README.md">
            <button>&#8592; Chapter 12</button>
        </a>
    </div>

</div>
<hr>